export default [
  { target: 'mammal', source: 'dog', strength: 0.7 },
  { target: 'mammal', source: 'cat', strength: 0.7 },
  { target: 'mammal', source: 'fox', strength: 0.7 },
  { target: 'mammal', source: 'elk', strength: 0.7 },
  { target: 'insect', source: 'ant', strength: 0.7 },
  { target: 'insect', source: 'bee', strength: 0.7 },
  { target: 'fish', source: 'carp', strength: 0.7 },
  { target: 'fish', source: 'pike', strength: 0.7 },
  { target: 'cat', source: 'elk', strength: 0.1 },
  { target: 'carp', source: 'ant', strength: 0.1 },
  { target: 'elk', source: 'bee', strength: 0.1 },
  { target: 'dog', source: 'cat', strength: 0.1 },
  { target: 'fox', source: 'ant', strength: 0.1 },
  { target: 'pike', source: 'cat', strength: 0.1 }
]
