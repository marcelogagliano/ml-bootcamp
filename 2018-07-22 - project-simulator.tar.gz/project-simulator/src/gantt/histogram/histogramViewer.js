function toArray(originalArray) {
    var result = [];
    for (var i = 0; i < originalArray.length; i++) {
        result.push(originalArray[i].value);
    }
    return result;
}


function getMontecarloData() {
var montecarloArray = localStorage.getItem('montecarloArray');
    //console.log(montecarloArray);
    //console.log(JSON.parse("["+montecarloArray+"]"));
    return (JSON.parse("["+montecarloArray+"]"));
}


var data = getMontecarloData();

//console.log(data);

Highcharts.chart('container', {
    title: {
        text: 'Montecarlo Histogram'
    },
    xAxis: [{
        title: {
            text: 'Scenarios'
        },
        alignTicks: false,
        opposite: true
    }, {
        title: {
            text: 'Histogram'
        },
        alignTicks: false
    }],

    yAxis: [{
        title: {
            text: 'Duration'
        }
    }, {
        title: {
            text: 'Histogram'
        },
        opposite: true
    }],

    series: [{
        name: 'Histogram',
        type: 'histogram',
        xAxis: 1,
        yAxis: 1,
        baseSeries: 's1',
        zIndex: -1
    }, {
        name: 'Scenario',
        type: 'scatter',
        data: data,
        id: 's1',
        marker: {
            radius: 1.5
        }
    }]
});