
var app = angular.module('myApp', ['ngAnimate', 'ui.bootstrap']);

app.controller('ModalCtrl', function ($scope, $uibModal) {
  
  $scope.animationsEnabled = true;
  
  $scope.open = function (templateUrl) {
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: templateUrl,
      controller: 'ModalInstanceCtrl',
      windowClass: 'modal-full'
    });
  };
});

app.controller('ModalInstanceCtrl', function ($scope, $modalInstance) {
  $scope.close = function () {
    $modalInstance.close();
  };
});

app.controller('FigureCtrl', function ($scope) {
  $scope.myData = [10, 20, 30, 40, 50, 68, 88, 20, 10, 40];
});


app.directive('barChart', function () {

  var directiveDefinitionObject = {
    restrict: 'E',
    replace: false,
    scope: {data: '=chartData', 
            width: '=width',
            height: '=height'
    },
    link: function (scope, element, attrs) {
      var chart = d3.select(element[0]);
      chart.append("div")
        .attr("class", "chart")
        .attr("width", scope.width)
        .attr("height", scope.height)
        .selectAll('div')
          .data(scope.data).enter().append("div")
          .transition().ease("elastic")
          .style("width", function(d) { return d + "%"; })
          .text(function(d) { return d + "%"; });
    } 
  };
  return directiveDefinitionObject;
});

app.directive('figure2', function ($watch) {
  return {
    restrict: 'E',
    replace: false,
    scope: {width: '=width',
            height: '=height'
    },
    link: function (scope, element, attrs) {
      
      var data = [2, 7, 12, 8, 11, 4];
      var minW = 200;
      var minH = 200;
      
      var width, height;
      
      // draw figure once parent has some dimensions > minW/minH
      
      scope.getParentSize = function () {
        return {  'w': element[0].parentElement.clientWidth, 
                  'h': element[0].parentElement.clientHeight };
      };
      
      scope.$watch(scope.getParentSize, function (newValue, oldValue) {
        alert ("ParentSize changed!");
        
        if (!newValue) {
          element[0].text = "Error - newValue not defined.";
          return;
        } 
        
        if (newValue.w < minW) {
          width = minW;
        } else {
          width = newValue.w;
        }
        
        if (newValue.h < minH) {
          height = minH;
        } else {
          height = newValue.h;
        }
        
        
        // Draw the simple bar chart
        var xScale = d3.scale.ordinal()
  					.domain([0, 1, 2, 3, 4, 5])
  					.rangeRoundBands([0, width], 0.1);
  			
  			var yScale = d3.scale.linear()
    				.domain([0, d3.max(data)])
    				.range([height, 0]);
  			
        var chart = d3.select(element[0]).append("svg")
          .attr("class", "chart")
          .attr("width", width)
          .attr("height", height)
          .selectAll('rect')
            .data(data).enter().append("rect")
            .attr("x", function(d, i) { return xScale(i); } ) 
  					.attr("y", function(d) { return yScale(d); })
  					.attr("height", function(d) { return height - yScale(d); })
  					.attr("width", xScale.rangeBand())
            .text(function(d) { return d ; });
  
      }, true);
      
      element.bind('resize', function () {
        scope.$apply();
      });
      
      
      
    } 
  };

});


