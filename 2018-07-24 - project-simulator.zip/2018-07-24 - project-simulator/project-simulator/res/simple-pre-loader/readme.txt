License
Copyright (c) 2014 SmallEnvelop.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Resource you have downloaded from SmallEnvelop.com is royalty free for use in both 
personal and commercial projects.

Rights

You may modify the resource according to your requirements and include it into 
works, such as websites, applications or other materials intended for sale. It is not 
necessary to link back to PixelBuddha.net, but we appreciate if you do credit our 
resources.

Prohibitions
You do not have the rights to redistribute, resell, lease, license, sub-license or offer 
this resource to any third party �as is� or as a separate attachment from any of your 
work. If you wish to use the resource as item or template that will be sold on a 
website or marketplace, we ask of you to contact us to determine the proper use of 
our resource before doing so.

Contact us � smallenvelop@gmail.com
� SmallEnvelop 2014