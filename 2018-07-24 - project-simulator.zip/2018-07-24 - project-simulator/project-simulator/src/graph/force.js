//Instantiate the SVG where the graph will be rendered:
var svg = d3.select("svg"),
    width = +svg.attr("width"),
    height = +svg.attr("height"),
    margin = 100;

var x_center = width / 2,
    y_center = height / 2,
    radius = (height - 2 * margin) / 2;

var n_elements;
function index_to_rad(index) {
  return 2 * Math.PI * index / n_elements;
}

var color = d3.scaleOrdinal(d3.schemeCategory20);

var simulation = d3.forceSimulation()
    //pull nodes together based on the links between them:
    .force("link", d3.forceLink().id(function(d) { return d.id; }))

    //create a repulsion charge to avoid the nodes being too close together
    .force("charge", d3.forceManyBody())

//    .force("collide", d3.forceCollide().radius(12))

    .force("center", d3.forceCenter(width / 2, height / 2));

    d3.select("input[type=range]")
    .on("input", inputted);

    var x_scale = d3.scaleLinear()
    .domain([0,1])
    .range([x_center, x_center + radius]);

var y_scale = d3.scaleLinear()
    .domain([0,1])
    .range([y_center, y_center + radius]);

d3.json("miserables.json", function(error, graph) {
  if (error) throw error;

  n_elements = graph.nodes.length;

  var link = svg.append("g")
      .attr("class", "links")
    .selectAll("line")
    .data(graph.links)
    .enter().append("line")
      .attr("stroke-width", function(d) { return Math.sqrt(d.value); });

  var node = svg.append("g")
      .attr("class", "nodes")
    .selectAll("g")
    .data(graph.nodes)
    .enter().append("g")
    
  var circles = node.append("circle")
      .attr("r", 5)
      .attr("fill", function(d) { return color(d.group); })
      .call(d3.drag()
          .on("start", dragstarted)
          .on("drag", dragged)
          .on("end", dragended));

  var labels = node.append("text")
      .text(function(d) {
        return d.id;
      })
      .attr('x', 6)
      .attr('y', 3);

  node.append("title")
      .text(function(d) { return d.id; });

  var max_value = d3.max(graph.links, function(d){ return d.value; });


  simulation
      .nodes(graph.nodes)
      .on("tick", ticked);

  simulation.force("link")
      .links(graph.links);

  function ticked() {
    link
        .attr("x1", function(d) { return d.source.x; })
        .attr("y1", function(d) { return d.source.y; })
        .attr("x2", function(d) { return d.target.x; })
        .attr("y2", function(d) { return d.target.y; });

    node
        .attr("transform", function(d) {
          return "translate(" + d.x + "," + d.y + ")";
        });
  }
});

///////////////////////////
d3.selectAll("#controls input[name=mode]").on("change", function(){
    if (this.value == 'circle') { 
    //console.log(this.value);
      var circles = svg.selectAll("circle")._groups[0];
      
      //console.log(circles);

      svg.selectAll("circle").data().forEach(function(d,i){
        d.x_resume = circles[i].cx.animVal.value;
        d.y_resume = circles[i].cy.animVal.value;
      });
      
      svg.selectAll('line')
        .transition().duration(1000)
          .attr('x1', function(d){ return x_scale(Math.sin(index_to_rad(d.source.index))); })
          .attr('x2', function(d){ return x_scale(Math.sin(index_to_rad(d.target.index))); })
          .attr('y1', function(d){ return y_scale(Math.cos(index_to_rad(d.source.index))); })
          .attr('y2', function(d){ return y_scale(Math.cos(index_to_rad(d.target.index))); });
      
      svg.selectAll("circle")
        .transition().duration(1000)
          .attr('x', function(d,i){ return x_scale(Math.sin(index_to_rad(i))); })
          .attr('y', function(d,i){ return y_scale(Math.cos(index_to_rad(i))); });

    } else { 

      svg.selectAll('line')
        .transition().duration(1000)
          .attr('x1', function(d){ return d.source.x_resume; })
          .attr('y1', function(d){ return d.source.y_resume; })
          .attr('x2', function(d){ return d.target.x_resume; })
          .attr('y2', function(d){ return d.target.y_resume; });

      svg.selectAll('circle')
        .transition().duration(1000)
          .attr('x', function(d){ return d.x_resume; })
          .attr('y', function(d){ return d.y_resume; });      

    }

});
///////////////////////////

function dragstarted(d) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d.fx = d.x;
  d.fy = d.y;
}

function dragged(d) {
  d.fx = d3.event.x;
  d.fy = d3.event.y;
}

function dragended(d) {
  if (!d3.event.active) simulation.alphaTarget(0);
  d.fx = null;
  d.fy = null;
}


function inputted() {
  simulation.force("link").strength(+this.value);
  simulation.alpha(1).restart();
}


