Screen 1 - Overview of the main screen: Has a Task list similar to MS Project and a Gantt chart visualization, with critical path highlighting as well.

Screen 2 - Creating a Task: Allows you to create a task, assigning resources, roles and Minimum and Maximum duration, that will be used for simulations.

Screen 3 - Simulation setup: Here you set how many scenarios will be simulated.

Screen 4 - Histogram with Simulation Results and Probabilistic Distribution: Once all the simulation run, it plots all of them in a histogram and present the probability of each scenario, allowing the project manager to more accurately establish how long a project will take.

Screen 5 - Hierarchical view of the project for Presentations: It is a visual way to present the project tasks, useful for presentations, where you have to give a quick introduction to the plan.

Screen 6 - Stakeholder x Tasks Graph: Here you can see in a more visually fashion which stakeholders are associated with each task. It is more efficient than a tabular view and allows you to notice anomalies, like overloaded stakeholders.