function confidenceInterval(array, z) {
    var nArray = toArray(array);
    return ([math.mean(nArray) - z * math.std(nArray) / (math.pow(nArray.length, 0.5)), math.mean(nArray) + z * math.std(nArray) / (math.pow(nArray.length, 0.5))]);
}


function toArray(originalArray) {
    var result = [];
    for (var i = 0; i < originalArray.length; i++) {
        result.push(originalArray[i].value);
    }
    return result;
}

function frequencyArray(array) {
    var a = [],
        b = [],
        prev;
    var result = [];
    array.sort();
    for (var i = 0; i < array.length; i++) {
        if (array[i] !== prev) {
            a.push(array[i]);
            b.push(1);
        } else {
            b[b.length - 1]++;
        }
        prev = array[i];
    }

    for (var j = 0; j < a.length; j++) {
        result.push({
            "value": a[j],
            "count": b[j]
        });
    }

    return result;
}

function frequency(array, element) {
    var f = frequencyArray(array);
    var result = 0;

    for (var i = 0; i < f.length; i++)
        if (element == f[i].value)
            result = f[i].count;

    return result;
}

function IQR(array) {

    var nArray = toArray(array);

    var a = math.quantileSeq(nArray, 0.75);
    var b = math.quantileSeq(nArray, 0.25);

    return a - b;
}

function getMontecarloData() {
    return (JSON.parse(localStorage.getItem('montecarloStorage')));
}


function transformData(monteCarloValues) {
    var result = {
        "items": []
    };

    var nArray = toArray(monteCarloValues.items);
    var set = new Set(nArray);
    var uniqueValues = Array.from(set);
    
    for (var i = 0; i < uniqueValues.length; i++) {
        result.items.push({
            "value": uniqueValues[i],
            "count": frequency(nArray, uniqueValues[i])
        });
    }

    return result;
}

(function ($, window, document, undefined) {
    var pluginName = "histogramSlider",
        dataKey = "plugin_" + pluginName;

    var updateHistogram = function (selectedRange, sliderMin, rangePerBin, histogramName, sliderName) {
        var leftValue = selectedRange[0],
            rightValue = selectedRange[1];

        $("#" + sliderName + "-value").html(leftValue + " - " + rightValue);

        // set opacity per bin based on the slider values
        $("#" + histogramName + " .in-range").each(function (index, bin) {
            var binRange = getBinRange(rangePerBin, index, sliderMin);

            if (binRange[1] < rightValue) {
                // Set opacity based on left (min) slider
                if (leftValue > binRange[1]) {
                    setOpacity(bin, 0);
                } else if (leftValue < binRange[0]) {
                    setOpacity(bin, 1);
                } else {
                    //setOpacity(bin, 1);
                    setOpacity(bin, 1 - (leftValue - binRange[0]) / rangePerBin);
                }
            } else if (binRange[0] > leftValue) {
                // Set opacity based on right (max) slider value
                if (rightValue > binRange[1]) {
                    setOpacity(bin, 1);
                } else if (rightValue < binRange[0]) {
                    setOpacity(bin, 0);
                } else {
                    //setOpacity(bin, 1);
                    setOpacity(bin, (rightValue - binRange[0]) / rangePerBin);
                }
            }
        });
    };

    var getBinRange = function (rangePerBin, index, sliderMin) {
        var min = (rangePerBin * index) + sliderMin,
            max = rangePerBin * (index + 1) - 1;

        return [min, max];
    }

    var setOpacity = function (bin, val) {
        $(bin).css("opacity", val);
    };

    var convertToHeight = function (v) {
        return parseInt(5 * v + 1);
    }

    var calculateHeightRatio = function (bins, histogramHeight) {
        var maxValue = Math.max.apply(null, bins);
        var height = convertToHeight(maxValue);

        if (height > histogramHeight) {
            return histogramHeight / height;
        }

        return 1;
    }

    var Plugin = function (element, options) {
        this.element = element;

        this.options = {
            sliderRange: [0, 0], // Min and Max slider values
            optimalRange: [0, 0], // Optimal range to select within
            selectedRange: [0, 0], // Min and Max slider values selected
            height: 0,
            numberOfBins: 0,
            showTooltips: false,
            showSelectedRange: false
        };

        this.init(options);
    };

    Plugin.prototype = {
        init: function (options) {
            $.extend(this.options, options);

            var self = this,
                dataItems = self.options.data.items,
                bins = new Array(this.options.numberOfBins).fill(0),
                range = self.options.sliderRange[1] - self.options.sliderRange[0],
                rangePerBin = range / this.options.numberOfBins;

            for (i = 0; i < dataItems.length; i++) {
                var index = parseInt(dataItems[i].value / rangePerBin),
                    increment = 1;

                if (dataItems[i].count) {
                    // Handle grouped data structure
                    increment = parseInt(dataItems[i].count);
                }

                bins[index] += increment;
            }

            var histogramName = self.element.attr('id') + "-histogram",
                sliderName = self.element.attr('id') + "-slider";

            var wrapHtml = "<div id='" + histogramName + "' style='height:" + self.options.height + "px; overflow: hidden;'></div>" +
                "<div id='" + sliderName + "'></div>";

            self.element.html(wrapHtml);

            var heightRatio = calculateHeightRatio(bins, self.options.height),
            widthPerBin = 100 / this.options.numberOfBins;    
            widthPerBin = math.mean(toArray(getMontecarloData().items)) / this.options.numberOfBins;

            console.log(heightRatio);

            for (i = 0; i < bins.length; i++) {
                var binRange = getBinRange(rangePerBin, i, this.options.sliderRange[0]),
                    inRangeClass = "bin-color-selected",
                    outRangeClass = "bin-color";

                if (self.options.optimalRange[0] <= binRange[0] && binRange[0] <= self.options.optimalRange[1]) {
                    inRangeClass = "bin-color-optimal-selected";
                    outRangeClass = "bin-color-optimal";
                }

                var toolTipHtml = self.options.showTooltips ? "<span class='tooltiptext'>" + binRange[0] + " - " + binRange[1] + "</br>count: " + bins[i] + "</span>" : "";

                var scaledValue = parseInt(bins[i] * heightRatio),
                    height = convertToHeight(scaledValue),
                    inRangeOffset = parseInt(self.options.height - height),
                    outRangeOffset = -parseInt(self.options.height - height * 2);

                var binHtml = "<div class='tooltip' style='float:left!important;width:" + widthPerBin + "%;'>" +
                    toolTipHtml +
                    "<div class='bin in-range " + inRangeClass + "' style='height:" + height + "px;bottom:-" + inRangeOffset + "px;position: relative;'></div>" +
                    "<div class='bin out-of-range " + outRangeClass + "' style='height:" + height + "px;bottom:" + outRangeOffset + "px;position: relative;'></div>" +
                    "</div>";

                $("#" + histogramName).append(binHtml);
            }

            $("#" + sliderName).slider({
                range: true,
                min: self.options.sliderRange[0],
                max: self.options.sliderRange[1],
                values: self.options.selectedRange,
                slide: function (event, ui) {
                    updateHistogram(ui.values, self.options.sliderRange[0], rangePerBin, histogramName, sliderName);
                }
            });

            if (self.options.showSelectedRange) {
                $("#" + sliderName).after("<p id='" + sliderName + "-value' class='selected-range'></p>");
            }

            updateHistogram(self.options.selectedRange, self.options.sliderRange[0], rangePerBin, histogramName, sliderName);
        }
    };

    $.fn[pluginName] = function (options) {
        var plugin = this.data(dataKey);

        if (plugin instanceof Plugin) {
            if (typeof options !== 'undefined') {
                plugin.init(options);
            }
        } else {
            plugin = new Plugin(this, options);
            this.data(dataKey, plugin);
        }

        return plugin;
    };

}(jQuery, window, document));

$(function () {
    var monteCarloValues = getMontecarloData();
    var nArray = toArray(monteCarloValues.items);
    var data = transformData(monteCarloValues);

    var h = 2 * IQR(data.items) / (math.pow(data.items.length, 1 / 3));
    if(h != 0)
    numBins = math.round((math.max(nArray) - math.min(nArray))/h); // Freedman–Diaconis' choice
else
    numBins = math.round(math.log(nArray.length)) + 1;

    if(numBins < 5)
        numBins = numBins*10;

    console.log(numBins);

    console.log(math.max(nArray));
    console.log(math.min(nArray));
    console.log(math.round(confidenceInterval(data.items, 2.58)[0]), math.round(confidenceInterval(data.items, 2.58)[1]));
    console.log(math.round(confidenceInterval(data.items, 1.96)[0]), math.round(confidenceInterval(data.items, 1.96)[1]));


    $("#histogramSlider").histogramSlider({
        data: data,
        sliderRange: [0, 2*math.max(nArray)],
        optimalRange: [math.round(confidenceInterval(data.items, 2.58)[0]), math.round(confidenceInterval(data.items, 2.58)[1])],
        selectedRange: [math.min(nArray), math.max(nArray)],
        numberOfBins: numBins,
        height: 200,
        showTooltips: true,
        showSelectedRange: true
    });

    numBins = 20;

    renderData(data);

    function renderData(data) {
        var dataArray = [];

        for (var i = 0; i < data.items.length; i++) {
            dataArray.push(data.items[i].value);
        }

        dataArray = dataArray.sort(function (a, b) {
            return b - a;
        });

        var count = 0,
            dataTable = $("#data");

        for (var i = 0; i < dataArray.length; i++) {
            count++;
            dataTable.after("<tr><td>" + dataArray[i] + "</td><td>" + count + "</td></tr>");

            if (round25000(dataArray[i]) > round25000(dataArray[i + 1])) {
                count = 0;
                dataTable.after("<tr><td>----------</td></tr>");
            }
        }
    }

    function round25000(x) {
        return Math.ceil(x / 25000) * 25000;
    }
});