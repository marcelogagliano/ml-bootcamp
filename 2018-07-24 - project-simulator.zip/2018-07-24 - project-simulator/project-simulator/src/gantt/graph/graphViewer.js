var svg = d3.select("svg");

var strokeOpacity = 1,
    fillOpacity = 1,
    stroke = "#ddd";

var strokeWidth,
    radius,
    labelSize = 12,
    labelFont = "Arial",
    labelAnchor = "middle";

var width = +svg.node().getBoundingClientRect().width - 350,
    height = +svg.node().getBoundingClientRect().height - 200;

var linkedByIndex = {};
// svg objects

var node, circle, label, g;
// the data - an object with nodes and links
var graph;

var selectedNodes = [];
var graphConnections = [];

// load the data
graph = d3.json("sample-data.json", function (error, _graph) {
    if (error) throw error;
    //graph = _graph;
    graph = JSON.parse(localStorage.getItem('graphJSON'));

    

    initializeDisplay();
    initializeSimulation();
});


//////////// FORCE SIMULATION //////////// 

// force simulator
var simulation = d3.forceSimulation();

var color = d3.scaleOrdinal(d3.schemeCategory20);

// set up the simulation and event to update locations after each tick
function initializeSimulation() {
    simulation.nodes(graph.nodes);
    initializeForces();
    simulation.on("tick", ticked);
}

function resetSimulation() {
    //console.log("RESET");
    //console.log(forceProperties);
    restorePosition();
    forceProperties = initialForceProperties;
    //console.log(forceProperties);
    initializeSimulation();
    updateAll();
}

// values for all forces
initialForceProperties = {
    center: {
        x: 0.5,
        y: 0.5
    },
    charge: {
        enabled: true,
        strength: -50,
        distanceMin: 1,
        distanceMax: 2000
    },
    collide: {
        enabled: false,
        strength: 1,
        iterations: 1,
        radius: 5
    },
    forceX: {
        enabled: false,
        strength: .1,
        x: .5
    },
    forceY: {
        enabled: false,
        strength: .1,
        y: .5
    },
    link: {
        enabled: true,
        distance: 30,
        iterations: 1
    },
    nodeLabel: {
        enabled: true,
        size: 10
    }
}

forceProperties = {
    center: {
        x: initialForceProperties.center.x,
        y: initialForceProperties.center.y
    },
    charge: {
        enabled: initialForceProperties.charge.enabled,
        strength: initialForceProperties.charge.strength,
        distanceMin: initialForceProperties.charge.distanceMin,
        distanceMax: initialForceProperties.charge.distanceMax
    },
    collide: {
        enabled: initialForceProperties.collide.enabled,
        strength: initialForceProperties.collide.strength,
        iterations: initialForceProperties.collide.iterations,
        radius: initialForceProperties.collide.radius
    },
    forceX: {
        enabled: initialForceProperties.forceX.enabled,
        strength: initialForceProperties.forceX.strength,
        x: initialForceProperties.forceX.x
    },
    forceY: {
        enabled: initialForceProperties.forceY.enabled,
        strength: initialForceProperties.forceY.strength,
        y: initialForceProperties.forceY.y
    },
    link: {
        enabled: initialForceProperties.link.enabled,
        distance: initialForceProperties.link.distance,
        iterations: initialForceProperties.link.iterations
    },
    nodeLabel: {
        enabled: initialForceProperties.nodeLabel.enabled,
        size: initialForceProperties.nodeLabel.size
    }
};

// add forces to the simulation
function initializeForces() {
    // add forces and associate each with a name
    simulation
        .force("link", d3.forceLink())
        .force("charge", d3.forceManyBody())
        .force("collide", d3.forceCollide())
        .force("center", d3.forceCenter())
        .force("forceX", d3.forceX())
        .force("forceY", d3.forceY());
    // apply properties to each of the forces
    updateForces();
}

// apply new force properties
function updateForces() {
    // get each force by name and update the properties
    simulation.force("center")
        .x(width * forceProperties.center.x)
        .y(height * forceProperties.center.y);
    simulation.force("charge")
        .strength(forceProperties.charge.strength * forceProperties.charge.enabled)
        .distanceMin(forceProperties.charge.distanceMin)
        .distanceMax(forceProperties.charge.distanceMax);
    simulation.force("collide")
        .strength(forceProperties.collide.strength * forceProperties.collide.enabled)
        .radius(forceProperties.collide.radius)
        .iterations(forceProperties.collide.iterations);
    simulation.force("forceX")
        .strength(forceProperties.forceX.strength * forceProperties.forceX.enabled)
        .x(width * forceProperties.forceX.x);
    simulation.force("forceY")
        .strength(forceProperties.forceY.strength * forceProperties.forceY.enabled)
        .y(height * forceProperties.forceY.y);
    simulation.force("link")
        .id(function (d) {
            return d.id;
        })
        .distance(forceProperties.link.distance)
        .iterations(forceProperties.link.iterations)
        .links(forceProperties.link.enabled ? graph.links : []);

    // updates ignored until this is run
    // restarts the simulation (important if simulation has already slowed down)
    simulation.alpha(1).restart();
}


//////////// DISPLAY ////////////

// generate the svg objects and force simulation
function initializeDisplay() {

    link = svg.append("g")
        .attr("class", "links")
        .selectAll("line")
        .data(graph.links)
        .enter().append("line")
        .attr("stroke-width", function (d) {
            graphConnections.push([d.source, d.target]);
            return Math.sqrt(d.value);
        });

    //console.log(graphConnections[0]);

    // set the data and properties of node circles
    /**/
    node = svg.append("g")
        .attr("class", "nodes")
        .selectAll("circle")
        .data(graph.nodes)
        .enter()
        .append("circle")
        .attr("r", forceProperties.collide.radius)
        .attr("fill", function (d) {
            return color(d.group);
        })
        .on("dblclick", dblclick)
        .on("mouseover", mouseOver(0.3))
        .on("mouseout", mouseOut)
        .call(d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended));

    // add a label to each node
    label = svg.append("g")
        .attr("class", "nodes")
        .selectAll()
        .data(graph.nodes)
        .enter().append("text")
        .text(function (d) {
            return d.name;
        })
        .style("text-anchor", labelAnchor)
        .style("font-family", labelFont)
        .style("font-size", labelSize);



    linkedByIndex = {};
    var connections = graph.links;
    connections.forEach(function (d) {
        //console.log(d);
        //console.log(getNodeIndex(getNode(d.source)));
        linkedByIndex[d.source + "," + d.target] = 1;
        //console.log("[" + d.source +","+ d.target + "] = " + "1");
        //console.log(linkedByIndex)
        //console.log(d.source.index + " -> " + d.target.index);
    });

    // visualize the graph
    updateDisplay();
}

// update the display based on the forces (but not positions)
function updateDisplay() {
    strokeWidth = forceProperties.charge.enabled == false ? 0 : Math.abs(forceProperties.charge.strength) / 15;
    radius = forceProperties.collide.radius;
    labelOn = forceProperties.nodeLabel.enabled;
    labelSize = forceProperties.nodeLabel.enabled == false ? 0 : forceProperties.nodeLabel.size;
    node
        .attr("r", radius)
        .attr("stroke", forceProperties.charge.strength > 0 ? "blue" : "red")
        .attr("stroke-width", strokeWidth);

    link
        //.attr("stroke-width", forceProperties.link.enabled ? 1 : .5)
        .attr("opacity", strokeOpacity);

    label
        .style("font-size", labelSize);

}

// update the display positions after each simulation tick
function ticked() {
    link
        .attr("x1", function (d) {
            return d.source.x;
        })
        .attr("y1", function (d) {
            return d.source.y;
        })
        .attr("x2", function (d) {
            return d.target.x;
        })
        .attr("y2", function (d) {
            return d.target.y;
        });

    node
        .attr("cx", function (d) {
            return d.x;
        })
        .attr("cy", function (d) {
            return d.y;
        });

    label
        .attr("x", function (d) {
            return d.x;
        })
        .attr("y", function (d) {
            return d.y;
        });

    d3.select('#alpha_value').style('flex-basis', (simulation.alpha() * 100) + '%');
}



//////////// UI EVENTS ////////////

function dragstarted(d) {
    //console.log("dragstarted");
    if (!d3.event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
}

function dragged(d) {
    d.fx = d3.event.x;
    d.fy = d3.event.y;
}

function dragended(d) {
    if (!d3.event.active) simulation.alphaTarget(0.0001);
    //d.fx = null;
    //d.fy = null;
    selectedNodes.push(d);
}

// update size-related forces
d3.select(window).on("resize", function () {
    width = +g.node().getBoundingClientRect().width;
    height = +g.node().getBoundingClientRect().height;
    updateForces();
});

// convenience function to update everything (run after UI input)
function updateAll() {
    updateForces();
    updateDisplay();
}

function dblclick(d) {
    //console.log(d); 
    d.fx = null;
    d.fy = null;
    /*
    console.log(d.name + " is connected to: ");
    for (var i = 0; i < graphConnections.length; i++) {
        if (d.id == graphConnections[i][0])
            console.log(graphConnections[i][1]);
    }
    */
}

function restorePosition() {
    for (var i = 0; i < selectedNodes.length; i++) {
        selectedNodes[i].fx = null;
        selectedNodes[i].fy = null;
    }
    selectedNodes = [];
}


function getNode(id) {
    var nodeFound = null;
    var searchGraph = graph
    for (var i = 0; i < searchGraph.nodes.length; i++) {
        if (searchGraph.nodes[i].id == id) {
            nodeFound = searchGraph.nodes[i];
            i = searchGraph.nodes.length;
            break;
        }
    }
    //console.log(nodeFound);
    return (nodeFound);
}

function getNodeIndex(d) {
    //console.log(d);
    return (d.index);
}

// check the dictionary to see if nodes are linked

function isConnected(a, b) {
    for (var i = 0; i < graphConnections.length; i++) {
        //console.log(graphConnections[i][0]+" == " + a.id);
        //console.log(graphConnections[i][1]+" == " + b.id);
        if (graphConnections[i][0] == a.id)
            if (graphConnections[i][1] == b.id)
                return 1;
    }
    return 0;
}

// fade nodes on hover
function mouseOver(opacity) {
    return function (d) {
        // check all other nodes to see if they're connected
        // to this one. if so, keep the opacity at 1, otherwise
        // fade
        label.style("font-size", function (o) {
            if (d == o)
                return 12;

            if (isConnected(d, o) == 1)
                return 12;
            else
                return 0;
        });

        node.attr("r", function (o) {
            if (d == o)
                return radius * 2;
            if (isConnected(d, o) == 1)
                return radius * 2;
            else
                return radius;
        });

        node.style("stroke-opacity", function (o) {
            if (d == o)
                return strokeOpacity / 2;

            if (isConnected(d, o) == 1)
                return strokeOpacity / 2;
            else
                return opacity;
        });
        node.style("fill-opacity", function (o) {
            if (d == o)
                return fillOpacity;

            if (isConnected(d, o) == 1)
                return fillOpacity;
            else
                return opacity;

        });
        // also style link accordingly
        link.style("stroke-opacity", function (o) {

            if (o.source.id == d.id)
                return strokeOpacity / 2;
            if (o.target.id == d.id)
                return strokeOpacity / 2;
            else
                return opacity;

            //return o.source === d || o.target === d ? 1 : opacity;
        });

        link.style("stroke", function (o) {
            if (o.source.id == d.id)
                return "black";
            if (o.target.id == d.id)
                return "black";
            else
                return stroke;
        });

    };
}

function mouseOut() {
    node.attr("r", radius);
    node.style("stroke-opacity", strokeOpacity);
    node.style("fill-opacity", fillOpacity);
    link.style("stroke-opacity", strokeOpacity);
    link.style("stroke", stroke);
    label.style("font-size", labelSize);
}

function loopConnections() {
    var fullyConnected = true;
    //console.log("Number of Nodes = " + graph.nodes.length);

    for (var i = 0; i < graph.nodes.length; i++) {
        for (var j = 0; j < graph.nodes.length; j++)
            fullyConnected = isConnected(graph.nodes[i], graph.nodes[j]);
    }
    //console.log(fullyConnected);
    return (fullyConnected);
}

d3.selectAll("input[name='mode']").on("change", function () {
    if (this.value == "circle") radialMode();
    else {
        forceMode();
        resetSimulation()
    };
});


function radialMode() {
    var slice = 2 * 3.14 / graph.nodes.length;
    var angle;
    for (var i = 0; i < graph.nodes.length; i++) {
        angle = slice * i;
        graph.nodes[i].fx = 300 + 250 * Math.cos(angle);
        graph.nodes[i].fy = 300 + 250 * Math.sin(angle);

    }
}

function forceMode() {

    for (var i = 0; i < graph.nodes.length; i++) {
        graph.nodes[i].fx = null;
        graph.nodes[i].fy = null;

    }
}