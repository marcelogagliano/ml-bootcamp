#!/usr/bin/env bash

ARG1=${1:-8000}
python -m SimpleHTTPServer $ARG1
